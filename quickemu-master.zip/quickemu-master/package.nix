{
  lib,
  fetchFromGitHub,
  installShellFiles,
  makeWrapper,
  stdenv,
  testers,
  cdrtools,
  curl,
  gawk,
  gnugrep,
  gnused,
  jq,
  mesa-demos,
  pciutils,
  procps,
  python3,
  qemu_full,
  samba,
  socat,
  spice-gtk,
  swtpm,
  unzip,
  usbutils,
  util-linux,
  xdg-user-dirs,
  xrandr,
  zsync,
  OVMF ? null,
  OVMFFull ? null,
}:
let
  runtimePaths = [
    cdrtools
    curl
    gawk
    gnugrep
    gnused
    jq
    pciutils
    procps
    python3
    qemu_full
    samba
    socat
    swtpm
    unzip
    util-linux
    xrandr
    zsync
  ]
  ++ lib.optionals stdenv.hostPlatform.isLinux [
    mesa-demos
    OVMF
    OVMFFull
    usbutils
    xdg-user-dirs
  ];
  # Extract version using builtins.split to avoid regex backtracking on large files.
  # builtins.match with .* patterns on multi-kilobyte files can cause stack overflow.
  versionParts = builtins.split "readonly VERSION=\"([0-9]+\\.[0-9]+\\.[0-9]+)\"" (
    builtins.readFile ./quickemu
  );
  version = builtins.elemAt (builtins.elemAt versionParts 1) 0;
in
stdenv.mkDerivation (finalAttrs: {
  pname = "quickemu";
  version = version;
  src = lib.cleanSource ./.;

  postPatch = ''
    sed -i \
      ${
        lib.optionalString (OVMF != null && OVMFFull != null) ''
          -e '/OVMF_CODE_4M.secboot.fd/s|ovmfs=(|ovmfs=("${OVMFFull.firmware}","${OVMFFull.variablesMs}" |' \
          -e '/OVMF_CODE_4M.fd/s|ovmfs=(|ovmfs=("${OVMF.firmware}","${OVMF.variables}" |' \
        ''
      } \
      -e '/cp "''${VARS_IN}" "''${VARS_OUT}"/a chmod +w "''${VARS_OUT}"' \
      -e 's/Icon=.*qemu.svg/Icon=qemu/' \
      -e 's,\$(command -v smbd),${samba}/bin/smbd,' \
      quickemu
  '';

  nativeBuildInputs = [
    makeWrapper
    installShellFiles
  ];

  installPhase = ''
    runHook preInstall

    installManPage docs/quickget.1 docs/quickemu.1 docs/quickemu_conf.5
    install -Dm755 -t "$out/bin" chunkcheck quickemu quickget quickreport

    # spice-gtk needs to be put in suffix so that when virtualisation.spiceUSBRedirection
    # is enabled, the wrapped spice-client-glib-usb-acl-helper is used
    for f in chunkcheck quickget quickemu quickreport; do
      wrapProgram $out/bin/$f \
        --prefix PATH : "${lib.makeBinPath runtimePaths}" \
        --suffix PATH : "${lib.makeBinPath [ spice-gtk ]}"
    done

    runHook postInstall
  '';

  passthru.tests = testers.testVersion { package = finalAttrs.finalPackage; };

  meta = {
    description = "Quickly create and run optimised Windows, macOS and Linux virtual machines";
    homepage = "https://github.com/quickemu-project/quickemu";
    changelog = "https://github.com/quickemu-project/quickemu/releases/tag/${finalAttrs.version}";
    mainProgram = "quickemu";
    license = lib.licenses.mit;
    maintainers = with lib.maintainers; [
      fedx-sudo
      flexiondotorg
    ];
  };
})
